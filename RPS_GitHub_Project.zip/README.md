# Rock Paper Scissors (RPS)

A simple Rock Paper Scissors game made using HTML, CSS and JavaScript.

## Files
- `index.html` - Main webpage
- `style.css` - Page design
- `script.js` - Game logic

## How to Run
Open `index.html` in any modern web browser.

## GitHub Pages
After uploading these files to a public GitHub repository, enable GitHub Pages from:

Settings → Pages → Deploy from branch → main → /(root)

